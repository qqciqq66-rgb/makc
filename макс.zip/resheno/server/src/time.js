import { config } from './config.js';

const OFFSET_MS = config.utcOffsetHours * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

/** Календарная дата (год, месяц, день, день недели) в часовом поясе города. */
export function localParts(date = new Date()) {
  const shifted = new Date(date.getTime() + OFFSET_MS);
  return {
    year: shifted.getUTCFullYear(),
    month: shifted.getUTCMonth(),
    day: shifted.getUTCDate(),
    weekday: shifted.getUTCDay(),
    hours: shifted.getUTCHours(),
    minutes: shifted.getUTCMinutes()
  };
}

/** Сегодняшняя дата в городе в формате YYYY-MM-DD. */
export function todayLocal(date = new Date()) {
  const p = localParts(date);
  return `${p.year}-${String(p.month + 1).padStart(2, '0')}-${String(p.day).padStart(2, '0')}`;
}

/** Момент времени для локальных даты и времени в городе. */
export function fromLocal(year, month, day, hours = 0, minutes = 0) {
  return new Date(Date.UTC(year, month, day, hours, minutes) - OFFSET_MS);
}

/** Начало локальных суток (00:00), сдвинутых на dayOffset дней от date. */
export function startOfLocalDay(date = new Date(), dayOffset = 0) {
  const p = localParts(date);
  return fromLocal(p.year, p.month, p.day + dayOffset);
}

/**
 * Временное окно для ответа «когда»:
 * today — от текущего момента до конца суток,
 * tomorrow — завтрашние сутки,
 * weekend — ближайшие суббота и воскресенье (если сегодня выходной, то с текущего момента).
 */
export function windowFor(when, now = new Date()) {
  const today = startOfLocalDay(now);
  if (when === 'today') {
    return { from: now, to: new Date(today.getTime() + DAY_MS) };
  }
  if (when === 'tomorrow') {
    const from = new Date(today.getTime() + DAY_MS);
    return { from, to: new Date(from.getTime() + DAY_MS) };
  }
  // weekend
  const wd = localParts(now).weekday;
  if (wd === 6 || wd === 0) {
    const daysLeft = wd === 6 ? 2 : 1;
    return { from: now, to: new Date(today.getTime() + daysLeft * DAY_MS) };
  }
  const from = new Date(today.getTime() + (6 - wd) * DAY_MS);
  return { from, to: new Date(from.getTime() + 2 * DAY_MS) };
}

const dateFormatter = new Intl.DateTimeFormat('ru-RU', {
  timeZone: config.timeZone,
  weekday: 'short',
  day: 'numeric',
  month: 'long',
  hour: '2-digit',
  minute: '2-digit'
});

export function formatDateTime(iso) {
  return dateFormatter.format(new Date(iso));
}

export { DAY_MS };
