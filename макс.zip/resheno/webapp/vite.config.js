import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // В режиме разработки API обслуживает сервер из папки server
    proxy: { '/api': 'http://localhost:8080' }
  },
  build: {
    outDir: 'dist',
    sourcemap: false
  }
});
