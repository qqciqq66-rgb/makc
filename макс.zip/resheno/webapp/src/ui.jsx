import { Button, Spinner } from '@maxhub/max-ui';
import { useEffect } from 'react';

import { bridge } from './bridge.js';
import { capitalize, formatPrice, formatWhenShort } from './format.js';

export function Pill({ selected, onClick, children, count }) {
  return (
    <button
      type="button"
      className={`pill${selected ? ' pill_on' : ''}`}
      aria-pressed={selected}
      onClick={() => {
        bridge.haptic('select');
        onClick();
      }}
    >
      {children}
      {count > 0 && <span className="pill__count">{count}</span>}
    </button>
  );
}

export function Sheet({ title, onClose, footer, children }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div className="sheet" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" className="sheet__backdrop" aria-label="Закрыть" onClick={onClose} />
      <div className="sheet__panel">
        <div className="sheet__head">
          <h2 className="h2">{title}</h2>
          <button type="button" className="icon-btn" aria-label="Закрыть" onClick={onClose}>
            ✕
          </button>
        </div>
        <div className="sheet__body">{children}</div>
        {footer && <div className="sheet__foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Badges({ event }) {
  return (
    <span className="badges">
      <span className="badge">{event.age}+</span>
      {event.pushkin && <span className="badge badge_pushkin">Пушкинская карта</span>}
    </span>
  );
}

export function EventCard({ event, today, onOpen, highlighted, dimmed }) {
  return (
    <button
      type="button"
      className={`event${highlighted ? ' event_hl' : ''}${dimmed ? ' event_dim' : ''}`}
      onClick={() => onOpen(event)}
    >
      <span className="event__icon" aria-hidden>
        {event.icon}
      </span>
      <span className="event__body">
        <span className="event__cat">{capitalize(event.category)}</span>
        <span className="event__title">{event.title}</span>
        <span className="event__when">{formatWhenShort(event, today)}</span>
        {event.tags.length > 0 && (
          <span className="event__tags">
            {event.tags.map((t) => (
              <span key={t} className="tag">
                {t}
              </span>
            ))}
          </span>
        )}
        <span className="event__foot">
          <span className="event__price">{formatPrice(event)}</span>
          <Badges event={event} />
        </span>
      </span>
    </button>
  );
}

export function Pagination({ page, pages, total, onPage }) {
  if (pages <= 1) return null;
  return (
    <nav className="pager" aria-label="Страницы">
      <Button size="small" variant="secondary" disabled={page <= 1} onClick={() => onPage(page - 1)}>
        ← Назад
      </Button>
      <span className="pager__info">
        {page} из {pages}
        <span className="muted"> · {total}</span>
      </span>
      <Button size="small" variant="secondary" disabled={page >= pages} onClick={() => onPage(page + 1)}>
        Вперёд →
      </Button>
    </nav>
  );
}

export function Loader({ text }) {
  return (
    <div className="state" role="status">
      <Spinner size={28} />
      <p className="text">{text}</p>
    </div>
  );
}

export function StateBlock({ emoji, title, text, children, role = 'status' }) {
  return (
    <div className="state" role={role}>
      <div className="state__emoji" aria-hidden>
        {emoji}
      </div>
      {title && <h3 className="h3">{title}</h3>}
      {text && <p className="text muted">{text}</p>}
      {children && <div className="row row_center">{children}</div>}
    </div>
  );
}
